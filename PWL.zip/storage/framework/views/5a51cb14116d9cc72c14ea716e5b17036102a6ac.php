 <?php $__env->startSection('content'); ?>
<div class="col-md-9">
    <div class="card">
        <div class="card-header">
            <h3>Blogs</h3>
        </div>
        <div class="card-body">
            <table class="table table-striped">
                <tr>
                    <th>Title</th>

                    <th>Image</th>
                    <th>Description</th>
                    <th>Option</th>
                </tr>
                <?php $__currentLoopData = $show; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($s->title); ?></td>

                    <td>
                        <img src="<?php echo e(asset($s->image)); ?>" style="width: 60px" />
                    </td>
                    <td>
                        <?php echo e(Illuminate\Support\Str::limit($s->description, 10)); ?>

                    </td>
                    <td>
                        <a
                            href="<?php echo e(url('/admin/update/'.$s->id)); ?>"
                            class="badge badge-warning"
                            >Update</a
                        >
                        <a
                            href="<?php echo e(url('/admin/delete/'.$s->id)); ?>"
                            class="badge badge-danger"
                            >Delete</a
                        >
                        <a
                            href="<?php echo e(url('/admin/detail/'.$s->id)); ?>"
                            class="badge badge-info"
                            >Detail</a
                        >
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
    <div class="mt-3">
        <?php echo e($show->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/user/Desktop/Laravel_Own_Creation_Pj/PwL_Design/resources/views/admin/show.blade.php ENDPATH**/ ?>