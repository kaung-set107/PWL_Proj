 <?php $__env->startSection('content'); ?>
<div class="row d-flex justify-content-between" id="head">
    <div class="col-md-6 mt-5">
        <h4 class="title mb-2">
            <b>Programming Skills</b>
        </h4>
        <i class="para mt-5">
            <p class="skill">
                <a
                    class="ic"
                    href="https://getbootstrap.com"
                    target="_blank"
                    rel="noreferrer"
                >
                    <img
                        src="https://raw.githubusercontent.com/devicons/devicon/master/icons/bootstrap/bootstrap-plain-wordmark.svg"
                        alt="bootstrap"
                        width="40"
                        height="40"
                    />
                </a>
                &nbsp;
                <a
                    class="ic"
                    href="https://www.w3schools.com/css/"
                    target="_blank"
                    rel="noreferrer"
                >
                    <img
                        src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original-wordmark.svg"
                        alt="css3"
                        width="40"
                        height="40"
                    />
                </a>
                &nbsp;
                <a
                    class="ic"
                    href="https://git-scm.com/"
                    target="_blank"
                    rel="noreferrer"
                >
                    <img
                        src="https://www.vectorlogo.zone/logos/git-scm/git-scm-icon.svg"
                        alt="git"
                        width="40"
                        height="40"
                    />
                </a>
                &nbsp;
                <a
                    class="ic"
                    href="https://www.w3.org/html/"
                    target="_blank"
                    rel="noreferrer"
                >
                    <img
                        src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original-wordmark.svg"
                        alt="html5"
                        width="40"
                        height="40"
                    /> </a
                >&nbsp;
                <a
                    class="ic"
                    href="https://developer.mozilla.org/en-US/docs/Web/JavaScript"
                    target="_blank"
                    rel="noreferrer"
                >
                    <img
                        src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg"
                        alt="javascript"
                        width="40"
                        height="40"
                    /> </a
                >&nbsp;
                <a
                    class="ic"
                    href="https://laravel.com/"
                    target="_blank"
                    rel="noreferrer"
                >
                    <img
                        src="https://raw.githubusercontent.com/devicons/devicon/master/icons/laravel/laravel-plain-wordmark.svg"
                        alt="laravel"
                        width="40"
                        height="40"
                    />
                </a>
                &nbsp;
                <a
                    class="ic"
                    href="https://www.mysql.com/"
                    target="_blank"
                    rel="noreferrer"
                >
                    <img
                        src="https://raw.githubusercontent.com/devicons/devicon/master/icons/mysql/mysql-original-wordmark.svg"
                        alt="mysql"
                        width="40"
                        height="40"
                    />
                </a>
                &nbsp;
                <a
                    class="ic"
                    href="https://www.php.net"
                    target="_blank"
                    rel="noreferrer"
                >
                    <img
                        src="https://raw.githubusercontent.com/devicons/devicon/master/icons/php/php-original.svg"
                        alt="php"
                        width="40"
                        height="40"
                    /> </a
                >&nbsp;
                <a
                    class="ic"
                    href="https://vuejs.org/"
                    target="_blank"
                    rel="noreferrer"
                >
                    <img
                        src="https://raw.githubusercontent.com/devicons/devicon/master/icons/vuejs/vuejs-original-wordmark.svg"
                        alt="vuejs"
                        width="40"
                        height="40"
                    />
                </a>
                &nbsp;
            </p>
        </i>

        <br />

        <div class="btn btn-sm btn-outline-info mt-5 rounded" id="viewall">
            <a href="<?php echo e(url('/view')); ?>"
                >View Projects &nbsp;<i class="fa fa-arrow-right"></i
            ></a>
        </div>
    </div>
    <div class="col-md-6 d-flex justify-content-end mt-5" id="image">
        <img src="/images/bllogo4.png" alt="" />
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/user/Desktop/Laravel_Own_Creation_Pj/PwL_Design/resources/views/skill.blade.php ENDPATH**/ ?>