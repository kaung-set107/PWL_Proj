 <?php $__env->startSection('content'); ?>
<div class="row mt-5 mb-4">
    <?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="col-md-4">
        <div class="card" id="viewbl">
            <div class="row mb-3">
                <div class="col-md-12">
                    <h4><?php echo e($p->title); ?></h4>
                </div>
            
                
            </div>
            <div class="row ml-2">
                <img src="<?php echo e(asset($p->image)); ?>" alt="" style="width: 80%" />
            </div>
            <div class="row mt-2">
                <div class="col-md-12">
                    <p>
                        <?php echo e(Illuminate\Support\Str::limit($p->description, 5)); ?>

                    </p>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <a
                    href="<?php echo e(url('/detail/'.$p->id)); ?>"
                    class="btn btn-sm btn-outline-info"
                    "
                    >View</a
                >
                </div>
                <div class="col-md-4 offset-2 mt-2">
                    <i
                        class="badge badge-secondary"
                        ><?php echo e($p->created_at->diffForHumans()); ?></i
                    >
                </div>
                
            </div>
        </div>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="mt-3">
    <?php echo e($project->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/user/Desktop/Laravel_Own_Creation_Pj/PwL_Design/resources/views/project.blade.php ENDPATH**/ ?>