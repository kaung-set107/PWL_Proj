 <?php $__env->startSection('content'); ?>

<div class="card contact mt-3 mb-3">
    <div class="card-header">
        <h3>Contact</h3>
    </div>
    <div class="card-body">
        <form action="" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="">Email</label>
                <input type="email" name="email" id="" class="form-control" />
            </div>
            <div class="form-group">
                <label for="">Message</label>
                <textarea
                    name="message"
                    id=""
                    cols="30"
                    rows="5"
                    class="form-control"
                ></textarea>
            </div>
            <input
                type="submit"
                value="Send"
                class="btn btn-sm btn-outline-success rounded"
            />
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/user/Desktop/Laravel_Own_Creation_Pj/PwL_Design/resources/views/contact.blade.php ENDPATH**/ ?>