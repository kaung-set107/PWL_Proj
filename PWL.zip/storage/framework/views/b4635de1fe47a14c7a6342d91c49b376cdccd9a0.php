 <?php $__env->startSection('content'); ?>
<div class="col-md-9">
    <div class="card">
        <div class="card-header">
            <h3>Create Your Blog</h3>
        </div>
        <div class="card-body">
            <form action="" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" name="title" class="form-control" />
                </div>
                <div class="form-group">
                    <label>Language</label><br />
                    <?php $__currentLoopData = $lan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="ml-3 mr-4">
                        <input
                            class="form-check-input"
                            type="checkbox"
                            name="language[]"
                            value="<?php echo e($l->id); ?>"
                        />
                        <label
                            class="form-check-label"
                            for="inlineCheckbox1"
                            ><?php echo e($l->name); ?></label
                        >
                    </span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="form-group">
                    <label>Image</label>
                    <input type="file" name="image" class="form-control" />
                </div>
                <div class="form-group">
                    <label>Developer Name</label>
                    <input
                        type="text"
                        name="dev_name"
                        id=""
                        class="form-control"
                    />
                </div>
                <div class="form-group">
                    <label>GitHub Link</label>
                    <input
                        type="text"
                        name="github"
                        id=""
                        class="form-control"
                    />
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea
                        name="description"
                        class="form-control"
                        cols="30"
                        rows="10"
                    ></textarea>
                </div>
                <input
                    type="submit"
                    value="Create"
                    class="btn btn-sm btn-outline-success"
                />
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/user/Desktop/Laravel_Own_Creation_Pj/PwL_Design/resources/views/admin/create.blade.php ENDPATH**/ ?>