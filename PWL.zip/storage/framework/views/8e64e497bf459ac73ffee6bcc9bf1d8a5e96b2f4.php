 <?php $__env->startSection('content'); ?>

<div class="col-md-12">
    <div class="card" id="viewbl">
        <div class="row pjhead mb-3">
            <div class="col-md-8 ml-2 mt-2">
                    <h3><?php echo e($project->title); ?></h3>
                    <?php $__currentLoopData = $project->language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <i class="badge badge-info"><?php echo e($l->name); ?></i>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-md-2 d-inline mt-2">
                    <small class="badge badge-light"
                        ><b class="badge badge-success">Posted</b>
                        <?php echo e($project->created_at->diffForHumans()); ?></small
                    >
                </div>
        </div>
        <div class="row mt-3 ml-2">
            <img src="<?php echo e(asset($project->image)); ?>" alt="" style="width: 90%" />
        </div>
        <div class="row mt-5">
            <h3>Project Info</h3>
            <table class="table table-striped">
                <tr>
                    <td>Developer Name</td>
                    <td><?php echo e($project->dev_name); ?></td>
                </tr>
                <tr>
                    <td>GitHub Link</td>
                    <td>
                        <a
                            href="<?php echo e($project->github); ?>" class="github_link"
                            ><?php echo e($project->github); ?></a
                        >
                    </td>
                </tr>
            </table>
        </div>
        <div class="row mt-5">
            <h3>Description</h3>
            <div class="col-md-12">
                <p>
                    <?php echo e($project->description); ?>

                </p>
            </div>
        </div>
        <div class="row mt-5">
            <h3>More Project Photos</h3>
            <div class="col-md-12">
                <img
                    src="<?php echo e(asset($project->image)); ?>"
                    style="width: 20%"
                    alt=""
                />
            </div>
        </div>
    </div>
    <div class="card mt-3 wrap">
        <div class="card-body">
            <div class="row comment d-inline">
                <form
                    action="<?php echo e(url('/comment')); ?>"
                    method="post"
                    class="cmtform"
                >
                    <?php echo csrf_field(); ?>
                    <input
                        type="hidden"
                        name="project_id"
                        value="<?php echo e($project->id); ?>"
                    />
                    <div class="form-group">
                        <textarea
                            name="message"
                            id=""
                            cols="20"
                            rows="3"
                            placeholder="Write Comment"
                            class="form-control"
                        ></textarea>
                    </div>
                    <input
                        type="submit"
                        value="Comment"
                        class="btn btn-sm btn-outline-success "
                    />
                </form>
            </div>
        </div>
        
            <h3 class=" px-2 py-3">Comments&nbsp;(<?php echo e(count($project->comments)); ?>)</h3>
            
                <?php $__currentLoopData = $project->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                        
                    <div class="card message mb-3 ml-3 mr-3">
                        <div class="row d-flex justify-content-between">
                            <div class="col-md-6">
                                <b><?php echo e($comment->message); ?></b>
                            </div>
                            <!-- <div class="col-md-1 ">
                        <a
                            href="<?php echo e(url('/commentdelete/'.$comment->id)); ?>"
                            class="badge badge-sm badge-danger cx"
                            >X</a
                        >
                        </div> -->
                    </div>
                
                </div>
        
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/user/Desktop/Laravel_Own_Creation_Pj/PwL_Design/resources/views/detail.blade.php ENDPATH**/ ?>