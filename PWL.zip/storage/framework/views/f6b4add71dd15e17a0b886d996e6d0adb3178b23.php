 <?php $__env->startSection('content'); ?>
<div class="row d-flex justify-content-between" id="head">
    <div class="col-md-6 mt-5">
        <h4 class="title mb-2">
            <b>Education</b>
        </h4>
        <i class="para"> <mark>Computer University (Monywa)</mark> </i>

        <br />

        <div class="btn btn-sm btn-outline-info mt-5 rounded" id="viewall">
            <a href="<?php echo e(url('/view')); ?>"
                >View Projects &nbsp;<i class="fa fa-arrow-right"></i
            ></a>
        </div>
    </div>
    <div class="col-md-6 d-flex justify-content-end mt-5" id="image">
        <img src="/images/bllogo4.png" alt="" />
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/user/Desktop/Laravel_Own_Creation_Pj/PwL_Design/resources/views/edu.blade.php ENDPATH**/ ?>